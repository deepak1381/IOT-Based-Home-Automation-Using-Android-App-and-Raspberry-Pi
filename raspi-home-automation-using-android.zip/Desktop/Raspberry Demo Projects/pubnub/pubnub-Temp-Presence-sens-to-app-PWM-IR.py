import RPi.GPIO as GPIO
import dht11
import time

from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
from pubnub.enums import PNStatusCategory
from pubnub.callbacks import SubscribeCallback



GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.cleanup()

pir = 36 #Assign pin 36 to PIR
led = 40 #Assign pin 40 to LED
ir=35    #Assign pin 35 to IR sensor
GPIO.setup(pir, GPIO.IN) #Setup GPIO pin PIR as input
GPIO.setup(led, GPIO.OUT) #Setup GPIO pin for LED as output
GPIO.setup(ir, GPIO.IN) #IR


pw = GPIO.PWM(40,100)          #GPIO19 as PWM output, with 100Hz frequency
pw.start(0)                              #generate PWM signal with 0% duty cycle

#mylcd = I2C_LCD_driver.lcd()

pnconfig = PNConfiguration()
pnconfig.publish_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
pnconfig.subscribe_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'

pubnub = PubNub(pnconfig)
channel1 = 'phue'
channel2 = 'deepak'
motion= False
smoke=False
visitor=False

class Listener(SubscribeCallback):
    
    
    def message(self, pubnub, message):   #take action based on  subscribe messages received

        pw.ChangeDutyCycle(message.message['GREEN'])               #change duty cycle for varying the brightness of LED.
        time.sleep(0.01)                           #sleep for 100m second
        
        if message.message['RED'] == 100:
            print(' ON Button pressed...')
            GPIO.output(led, GPIO.HIGH) # Turn on
            
           # pubnub.add_listener(Listener())
           # pubnub.publish().channel("phue").message({'fieldA': 'On Pressed', 'fieldB': 10}).sync()
            time.sleep(0.5)
            
        elif message.message['RED'] == 0:
            print('OFF Button pressed...')
            GPIO.output(led, GPIO.LOW) # Turn on
            
          #  pubnub.add_listener(Listener())
           #S pubnub.publish().channel("phue").message({'fieldA': 'Off Pressed', 'fieldB': 0}).sync()
            
            time.sleep(0.5)
        
        
print('Listening...')
pubnub.add_listener(Listener())
#pubnub.publish().channel("phue").message({'fieldA': 'Raspdata sent by Deepak before subscribe', 'fieldB': 10}).sync()
 
pubnub.subscribe().channels(channel1).execute()

'''
str_pad = " " * 16
my_long_string = "IOT Based Secured Home Automation"
my_long_string = str_pad + my_long_string

for i in range (0, len(my_long_string)):
 lcd_text = my_long_string[i:(i+16)]
 mylcd.lcd_display_string(lcd_text,1)
 time.sleep(0.01)
 mylcd.lcd_display_string(str_pad,1)
 
time.sleep(2)
mylcd.lcd_clear()

'''

while True:
  
  instance = dht11.DHT11(pin = 11)   #gpio 17
  result = instance.read()
  motion=False
  visitor=False
  temperature=result.temperature
  humidity=result.humidity
  

# Uncomment for Fahrenheit:
# result.temperature = (result.temperature * 1.8) + 32 

  if result.is_valid():
      
    
      #mylcd.lcd_display_string("Temp: %d%s C" % (result.temperature, chr(223)), 1)
      #time.sleep(1)
      #mylcd.lcd_clear()
      #mylcd.lcd_display_string("Humidity: %d %%" % result.humidity, 2)
      #time.sleep(0.5)
     # pubnub.publish().channel("deepak").message({'humi': result.humidity,'temp': result.temperature}).sync()
      temperature=result.temperature
      humidity=result.humidity
      print(result.temperature)
     
    
  if GPIO.input(pir) == True: #If PIR pin goes high, motion is detected
      print ("Motion Detected!")
      motion=True
      #GPIO.output(led, True) #Turn on LED
      #time.sleep(0.5) #Keep LED on for 4 seconds
      #GPIO.output(led, False) #Turn off LED
      
  if GPIO.input(ir)==False:
      visitor=True
      print("visitor")
      
      
      
      

      
  #print (motion)  
  if(GPIO.input(pir) or result.is_valid() or GPIO.input(ir)==False):
      pubnub.publish().channel("deepak").message({'humi': humidity,'temp': temperature, 'motion': motion,'smoke':smoke,'visitor' : visitor}).sync()    
      

