## Hello World, PubNub

import sys
from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub

mypubnubconfig = PNConfiguration()

mypubnubconfig.subscribe_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
mypubnubconfig.publish_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'
pubnub = PubNub(mypubnubconfig)

# Initiate Pubnub State - Get your own keys at admin.pubnub.com
#pubnub = PubNub(publish_key='pub-c-156a6d5f-22bd-4a13-848d-b5b4d4b36695', subscribe_key='sub-c-f762fb78-2724-11e4-a4df-02ee2ddab7fe')

channel = 'hello-pi'

username = 'Deepak'
message = 'Hello World from Pi!'

data = {
    'username': username,
    'message': message
}

# Asynchronous usage
def _callback(m,channel):
    print(m)

def _error(m):
    print(m)

pubnub.subscribe(channels=channel, callback=_callback, error=_error)

#pubnub.publish(channel, data, callback=callback, error=error)
