
#!/usr/bin/python
from pubnub.callbacks import SubscribeCallback
from pubnub.enums import PNStatusCategory
from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
import time
import RPi.GPIO as GPIO

pnconfig = PNConfiguration()

pnconfig.publish_key = 'pub-c-49d05748-917f-409f-a425-8f0bc9e281c0'
pnconfig.subscribe_key = 'sub-c-1ac5c480-fab9-11e8-9488-9e80330262eb'

 
pubnub = PubNub(pnconfig)


## Make your pin assignments
red_gpio   = 18
green_gpio = 23
blue_gpio  = 24

## Setup GPIO Board and Pins
GPIO.setmode(GPIO.BCM)    # BCM for GPIO numbering  
GPIO.setup(red_gpio,   GPIO.OUT)
GPIO.setup(green_gpio, GPIO.OUT)
GPIO.setup(blue_gpio,  GPIO.OUT)

## Init the GPIO PWMs
Freq  = 100 #Hz

RED   = GPIO.PWM(red_gpio, Freq)
RED.start(0)

GREEN = GPIO.PWM(green_gpio, Freq)
GREEN.start(0)

BLUE  = GPIO.PWM(blue_gpio, Freq)
BLUE.start(0)


# Update the hue with R G B values
def updateHue(R, G, B):
    rVal = 100 - (R/255.0)*100  # Will have to change these values depending on
    gVal = 100 - (G/255.0)*100  #  whether your LED has a common cathode or common
    bVal = 100 - (B/255.0)*100  #  anode. This code is for common anode.
    print( "rgb(%.2f, %.2f, %.2f)" % (rVal, gVal, bVal))
    RED.ChangeDutyCycle(rVal)
    GREEN.ChangeDutyCycle(gVal)
    BLUE.ChangeDutyCycle(bVal)


def rgb():
    updateHue(255,0,0); time.sleep(2)
    updateHue(0,255,0); time.sleep(2)
    updateHue(0,0,255); time.sleep(2)

def main():
    rgb()
    updateHue(0,0,0); # Light off
    # Instantiate Pubnub
    # This is the channel your Pi will be listening on for RGB values
    channel = 'phue'

    # The callback tells pubnub what to do when it received a message.
    def _callback(msg, n):
        print(msg)
        updateHue(msg["RED"], msg["GREEN"], msg["BLUE"])

    def _error(m):
        print(m)

    pubnub.subscribe().channels('phue').execute()
    
main()